/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.implementaciondemetodosdeunarbolbinario;
/**
 *
 * @author Alumno
 */
public class BinaryTreeComun<T> {
    public NodoArbolBinario<T> raiz;

    protected class NodoArbolBinario<T> {
        T dato;
        NodoArbolBinario<T> hijoIzq;
        NodoArbolBinario<T> hijoDer;

        public NodoArbolBinario(T dato) {
            this.dato = dato;
        }
    }

    public T getRootData() {
        if (raiz == null) {
            return null;
        }
        return raiz.dato;
    }

    public int getHeight() {
        return getHeight(raiz);
    }

    protected int getHeight(NodoArbolBinario<T> nodo) {
        int height = 0;
        if (nodo != null) {
            height = 1 + Math.max(getHeight(nodo.hijoIzq), getHeight(nodo.hijoDer));
        }
        return height;
    }

    public int getNumberNodes() {
        return getNumberNodes(raiz);
    }

    private int getNumberNodes(NodoArbolBinario<T> nodo) {
        if (nodo == null) {
            return 0;
        }
        int numNodosIzq = getNumberNodes(nodo.hijoIzq);
        int numNodosDer = getNumberNodes(nodo.hijoDer);
        return 1 + numNodosIzq + numNodosDer;
    }

    public boolean empty() {
        return raiz == null;
    }

    public void clear() {
        raiz = null;
    }
}
