/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.implementaciondemetodosdeunarbolbinario;

import com.clasedb.principal.Familiar;

/**
 *
 * @author HP
 */
public class ImplementaciondeMetodosdeunArbolBinario {

    public static void main(String[] args) {
         Familiar abuelo = new Familiar("Ernesto Perez", 78, "Jubilado", false, "Guadalajara");
        Familiar hijo1 = new Familiar("Carlos Perez", 50, "Ingeniero", false, "Ciudad de Mexico");
        Familiar hija2 = new Familiar("Maria Perez", 46, "Contadora", false, "Monterrey");
        Familiar nieto1 = new Familiar("Sofia Perez", 22, "Estudiante", false, "Puebla");
        Familiar nieto2 = new Familiar("Mateo Perez", 19, "Estudiante", false, "Puebla");

        BinaryTree<Familiar> arbolNieto1 = new BinaryTree<>(nieto1);
        BinaryTree<Familiar> arbolNieto2 = new BinaryTree<>(nieto2);
        BinaryTree<Familiar> arbolHijo1 = new BinaryTree<>(hijo1, arbolNieto1, arbolNieto2);
        BinaryTree<Familiar> arbolHija2 = new BinaryTree<>(hija2);
        BinaryTree<Familiar> arbolGenealogico = new BinaryTree<>(abuelo, arbolHijo1, arbolHija2);

        arbolGenealogico.preOrden(arbolGenealogico.raiz);

        arbolGenealogico.postOrden(arbolGenealogico.raiz);
    }
}
