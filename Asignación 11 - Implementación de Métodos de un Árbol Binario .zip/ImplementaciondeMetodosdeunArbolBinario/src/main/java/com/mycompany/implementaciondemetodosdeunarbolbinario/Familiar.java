/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.clasedb.principal;

/**
 *
 * @author Alumno
 */
public class Familiar {
    private String nombre;
    private int edad;
    private String ocupacion;
    private boolean finado;
    private String lugarDeNacimiento;

    public Familiar(String nombre, int edad, String ocupacion, boolean finado, String lugarDeNacimiento) {
        this.nombre = nombre;
        this.edad = edad;
        this.ocupacion = ocupacion;
        this.finado = finado;
        this.lugarDeNacimiento = lugarDeNacimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public boolean isFinado() {
        return finado;
    }

    public String getLugarDeNacimiento() {
        return lugarDeNacimiento;
    }

    @Override
    public String toString() {
        String estado = finado ? "Finado/a" : "Vivo/a";
        return nombre + " | Edad: " + edad + " | Ocupacion: " + ocupacion + " | Nacimiento: " + lugarDeNacimiento + " [" + estado + "]";
    }
}
