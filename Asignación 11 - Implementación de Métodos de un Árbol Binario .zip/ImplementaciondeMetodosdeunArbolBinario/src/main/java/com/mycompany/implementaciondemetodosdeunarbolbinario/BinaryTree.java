/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.implementaciondemetodosdeunarbolbinario;

/**
 *
 * @author Alumno
 */
public class BinaryTree<T> extends BinaryTreeComun<T> {
    public BinaryTree() {
        raiz = null;
    }

    public BinaryTree(T datoRaiz) {
        raiz = new NodoArbolBinario<>(datoRaiz);
    }

    public BinaryTree(T datoRaiz, BinaryTree<T> arbolIzq, BinaryTree<T> arbolDer) {
        setTree(datoRaiz, arbolIzq, arbolDer);
    }

    private void setTree(T datoRaiz, BinaryTree<T> arbolIzq, BinaryTree<T> arbolDer) {
        raiz = new NodoArbolBinario<>(datoRaiz);
        if ((arbolIzq != null) && !arbolIzq.empty()) {
            raiz.hijoIzq = copy(arbolIzq.raiz);
        }
        if ((arbolDer != null) && !arbolDer.empty()) {
            raiz.hijoDer = copy(arbolDer.raiz);
        }
    }

    private NodoArbolBinario<T> copy(NodoArbolBinario<T> nodo) {
        NodoArbolBinario<T> nuevoNodo = new NodoArbolBinario<>(nodo.dato);
        if (nodo.hijoIzq != null) {
            nuevoNodo.hijoIzq = copy(nodo.hijoIzq);
        }
        if (nodo.hijoDer != null) {
            nuevoNodo.hijoDer = copy(nodo.hijoDer);
        }
        return nuevoNodo;
    }

    public void preOrden(NodoArbolBinario<T> nodo) {
        if (nodo != null) {
            System.out.println(nodo.dato);
            preOrden(nodo.hijoIzq);
            preOrden(nodo.hijoDer);
        }
    }

    public void postOrden(NodoArbolBinario<T> nodo) {
        if (nodo != null) {
            postOrden(nodo.hijoIzq);
            postOrden(nodo.hijoDer);
            System.out.println(nodo.dato);
        }
    }
}
